function renderInicio(main) {
  main.innerHTML = `
    <section class="hero">
      <h1 class="hero-title">Bem‑vindo ao <span>FireAlert</span></h1>
      <p class="hero-sub">Criamos este aplicativo para prevenção de queimadas</p>
    </section>
    
    <section class="cards">


      <article class="card" tabindex="0">
        <div class="card-media">
          <img src="imgs/rj_recortadocolor1.png" alt="Mapa do Rio de Janeiro">
        </div>
        <div class="card-body">
          <h2 class="card-title">Mapa RJ</h2>
          <p class="card-desc">Visualize o mapa recortado do Rio de Janeiro.</p>
          <div class="card-actions">
            <button class="btn small" data-action="abrir-mapa-rj" data-title="Mapa RJ">Abrir</button>
            <button class="btn ghost small" data-action="share" data-title="Mapa RJ">Compartilhar</button>
          </div>
        </div>
      </article>


      <article class="card" tabindex="0">
        <div class="card-media">
          <img src="imgs/ilstc_florestal.jpg" alt="Imagem de um relatório ou alerta de incêndio">
        </div>
        <div class="card-body">
          <h2 class="card-title">Relatórios de possiveis incendios</h2>
          <p class="card-desc">Notas rápidas e atalhos.</p>
          <div class="card-actions">
            <button class="btn small" data-action="open" data-title="Relatórios de possiveis incendios" data-content="Notas rápidas e atalhos do relatório de incêndios.">Abrir</button>
            <button class="btn ghost small" data-action="share" data-title="Relatórios de possiveis incendios">Compartilhar</button>
          </div>
        </div>
      </article>


      
      <article class="card" tabindex="0">
        <div class="card-media">
          <img src="imgs/ondalistration.jpg" alt="Imagem representando o projeto Onda">
        </div>
        <div class="card-body">
          <h2 class="card-title">Projeto: Onda</h2>
          <p class="card-desc">Resumo curto do projeto com destaque e ações.</p>
          <div class="card-actions">
            <button class="btn small" data-action="open" data-title="Projeto: Onda" data-content=" Este aplicativo foi desenvolvido para auxiliar na prevenção de queimadas no estado do Rio de Janeiro, utilizando uma abordagem inovadora baseada em dados e cálculos. Ele analisa diversos fatores como clima, umidade, temperatura e outros indicadores ambientais para calcular o risco de incêndios em diferentes regiões. O objetivo é alertar autoridades e comunidades, promovendo ações preventivas mais eficientes, especialmente durante os períodos mais críticos. Com isso, o app visa proteger a biodiversidade local, minimizar danos ambientais e garantir a segurança das áreas urbanas e rurais.">Abrir</button>
            <button class="btn ghost small" data-action="share" data-title="Projeto: Onda">Compartilhar</button>
          </div>
        </div>
      </article>
      

    </section>
  `;
}

document.addEventListener('DOMContentLoaded', () => {
  const btnMenu = document.getElementById('btnMenu');
  const navDrawer = document.getElementById('navDrawer');
  const btnTheme = document.getElementById('btnTheme');
  const modal = document.getElementById('modal');
  const modalPanel = document.querySelector('.modal-panel');
  const modalOverlay = document.querySelector('.modal-overlay');
  const modalClose = document.getElementById('modalClose');
  const fab = document.getElementById('fab');
  const navLinks = document.querySelectorAll('.nav-link');
  const navItems = document.querySelectorAll('.bottom-nav .nav-item');
  const main = document.querySelector('main.content');
  const imageViewer = document.getElementById('imageViewer');
  const imageViewerContent = imageViewer ? imageViewer.querySelector('.image-viewer-content') : null;
  const imageViewerClose = document.querySelector('.image-viewer-close');
  const imageViewerImg = imageViewer ? imageViewer.querySelector('img') : null;
  const zoomSlider = document.getElementById('zoomSlider');
  const zoomSliderContainer = document.querySelector('.zoom-slider-container');


  // Preenche o conteúdo inicial
  if (main) renderInicio(main);

  // Drawer toggle
  btnMenu.addEventListener('click', () => {
    const open = navDrawer.classList.toggle('open');
    navDrawer.setAttribute('aria-hidden', String(!open));
    if (open && !document.getElementById('drawerOverlay')) {
      const overlay = document.createElement('div');
      overlay.id = 'drawerOverlay';
      overlay.style.position = 'fixed';
      overlay.style.top = 0;
      overlay.style.left = 0;
      overlay.style.width = '100vw';
      overlay.style.height = '100vh';
      overlay.style.background = 'rgba(0,0,0,0.3)';
      overlay.style.zIndex = 98;
      overlay.classList.add('fade-in');
      overlay.addEventListener('click', () => {
        navDrawer.classList.remove('open');
        navDrawer.setAttribute('aria-hidden', 'true');
        overlay.remove();
        navDrawer.style.zIndex = '';
      });
      navDrawer.parentNode.insertBefore(overlay, navDrawer);
      navDrawer.style.zIndex = 99;
    } else if (!open) {
      const overlay = document.getElementById('drawerOverlay');
      if (overlay) overlay.remove();
      navDrawer.style.zIndex = '';
    }
  });

  // Fecha drawer ao clicar em link do menu
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      navDrawer.classList.remove('open');
      navDrawer.setAttribute('aria-hidden', 'true');
      const overlay = document.getElementById('drawerOverlay');
      if (overlay) overlay.remove();
      navDrawer.style.zIndex = '';
      showToast(`Você navegou para: ${link.textContent}`);

      // Troca o conteúdo do main conforme o link do menu lateral
      if (!main) return;
      const target = link.dataset.target;
      if (target === 'inicio') {
        renderInicio(main);
      } else if (target === 'projetos') {
        main.innerHTML = `
          <section class="hero">
            <h1 class="hero-title">Projetos</h1>
            <p class="hero-sub">Veja seus projetos cadastrados.</p>
          </section>
        `;
      } else if (target === 'galeria') {
        main.innerHTML = `
          <section class="hero">
            <h1 class="hero-title">Galeria</h1>
            <p class="hero-sub">Suas imagens e arquivos.</p>
          </section>
        `;
      } else if (target === 'config') {
        main.innerHTML = `
          <section class="hero">
            <h1 class="hero-title">Configurações</h1>
            <p class="hero-sub">Ajuste preferências do app.</p>
          </section>
        `;
      }
    });
  });

  // Theme toggle
  const rootEl = document.body;
  const sunIcon = `<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 3v2M12 19v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>`;
  const moonIcon = `<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>`;

  function updateThemeIcon() {
    const isDark = rootEl.classList.contains('theme-dark');
    btnTheme.innerHTML = isDark ? sunIcon : moonIcon;
    btnTheme.setAttribute('aria-label', isDark ? 'Mudar para tema claro' : 'Mudar para tema escuro');
  }

  btnTheme.addEventListener('click', () => {
    rootEl.classList.toggle('theme-dark');
    rootEl.classList.toggle('theme-light');
    updateThemeIcon();
    btnTheme.classList.add('btn-animate');
    setTimeout(() => btnTheme.classList.remove('btn-animate'), 300);
  });

  // Define o ícone inicial ao carregar a página
  updateThemeIcon();

  // Modal open/close com animação
  function openModal(title, content) {
    document.getElementById('modalTitle').textContent = title || 'Detalhes';
    document.getElementById('modalContent').textContent = content || 'Conteúdo do modal.';
    modal.setAttribute('aria-hidden', 'false');
    modalPanel.classList.add('modal-show');
    setTimeout(() => modalPanel.classList.remove('modal-show'), 300);
  }
  function closeModal() {
    if (modal) modal.setAttribute('aria-hidden', 'true');
  }

  // Funções do visualizador de imagem
  function openImageViewer(src) {
    if (!imageViewer || !imageViewerImg || !imageViewerContent) return;

    // Reseta a posição do scroll
    imageViewerContent.scrollTop = 0;
    imageViewerContent.scrollLeft = 0;

    // Limpa estilos e dados da imagem anterior
    imageViewerImg.style.width = '';
    imageViewerImg.style.height = '';
    imageViewerImg.removeAttribute('data-initial-width');
    imageViewerImg.removeAttribute('data-initial-height');

    imageViewerImg.onload = () => {
      const { naturalWidth, naturalHeight } = imageViewerImg;
      const { clientWidth: viewerWidth, clientHeight: viewerHeight } = imageViewer;

      // Calcula a escala inicial para a imagem caber na tela, sem ampliar imagens pequenas
      const scale = Math.min(viewerWidth / naturalWidth, viewerHeight / naturalHeight, 1);

      const initialWidth = naturalWidth * scale;
      const initialHeight = naturalHeight * scale;

      imageViewerImg.dataset.initialWidth = initialWidth;
      imageViewerImg.dataset.initialHeight = initialHeight;
      imageViewerImg.style.width = `${initialWidth}px`;
      imageViewerImg.style.height = `${initialHeight}px`;
    };

    imageViewerImg.src = src;
    imageViewer.setAttribute('aria-hidden', 'false');
    // Reseta o zoom ao abrir
    if (zoomSlider) zoomSlider.value = 1;
  }
  function closeImageViewer() {
    if (imageViewer) imageViewer.setAttribute('aria-hidden', 'true');
    // Reseta o zoom para a próxima vez que abrir
    if (imageViewerImg) {
      imageViewerImg.style.width = '';
      imageViewerImg.style.height = '';
      imageViewerImg.removeAttribute('src'); // Evita que a imagem antiga apareça rapidamente
    }
  }

  // Gerenciador de eventos de clique principal
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;

    // Ação para abrir o mapa no visualizador de imagem
    if (btn.dataset.action === 'abrir-mapa-rj') {
      // Altere o caminho da imagem aqui para o seu arquivo.
      openImageViewer('imgs/rj_recortadocolor1.png');
      return; // Impede outras ações de botão
    }

    if (btn.dataset.action === 'open') {
      openModal(btn.dataset.title || 'Detalhes', btn.dataset.content || 'Você abriu um modal interativo!');
    }
    if (btn.dataset.action === 'share') {
      if (navigator.share) {
        navigator.share({
          title: btn.dataset.title || document.title,
          text: 'Compartilhe este projeto',
          url: location.href
        });
      } else {
        openModal('Compartilhar', 'Seu navegador não suporta compartilhamento.');
      }
    }
    if (btn.dataset.action === 'edit') {
      openModal(btn.dataset.title || 'Editar', 'Função de edição em breve!');
    }
    if (btn.classList.contains('nav-item')) {
      navItems.forEach(n => n.classList.remove('active'));
      btn.classList.add('active');
      showToast(`Você selecionou: ${btn.textContent}`);
    }
  });

  // Listeners para fechar modais e drawer
  modalClose?.addEventListener('click', closeModal);
  modalOverlay?.addEventListener('click', closeModal);

  imageViewerClose?.addEventListener('click', closeImageViewer);
  imageViewer?.addEventListener('click', (e) => {
    // Fecha somente se clicar no fundo (o próprio container)
    if (e.target === imageViewer) closeImageViewer();
  });

  // Impede que o toque na barra de zoom mova a imagem ao fundo
  zoomSliderContainer?.addEventListener('pointerdown', (e) => {
    e.stopPropagation();
  });

  zoomSlider?.addEventListener('input', (e) => {
    if (!imageViewerImg || !imageViewerContent) return;

    const initialWidth = parseFloat(imageViewerImg.dataset.initialWidth);
    const initialHeight = parseFloat(imageViewerImg.dataset.initialHeight);
    if (!initialWidth || !initialHeight) return;

    // --- Antes do zoom ---
    // Pega as dimensões da "janela" (viewport) e o scroll atual
    const viewerWidth = imageViewerContent.clientWidth;
    const viewerHeight = imageViewerContent.clientHeight;
    const oldScrollLeft = imageViewerContent.scrollLeft;
    const oldScrollTop = imageViewerContent.scrollTop;

    // Pega as dimensões antigas da imagem
    const oldImgWidth = imageViewerImg.width;
    const oldImgHeight = imageViewerImg.height;
    if (oldImgWidth === 0 || oldImgHeight === 0) return;

    // Encontra o ponto na imagem que está no centro da "janela"
    const centerX = oldScrollLeft + viewerWidth / 2;
    const centerY = oldScrollTop + viewerHeight / 2;

    // Calcula a proporção deste ponto central em relação ao tamanho total da imagem
    const ratioX = centerX / oldImgWidth;
    const ratioY = centerY / oldImgHeight;

    // --- Aplica o zoom ---
    const zoomLevel = e.target.value;
    const newImgWidth = initialWidth * zoomLevel;
    const newImgHeight = initialHeight * zoomLevel;
    imageViewerImg.style.width = `${newImgWidth}px`;
    imageViewerImg.style.height = `${newImgHeight}px`;

    // --- Depois do zoom ---
    // Calcula a nova posição do scroll para manter o mesmo ponto no centro
    const newScrollLeft = (newImgWidth * ratioX) - (viewerWidth / 2);
    const newScrollTop = (newImgHeight * ratioY) - (viewerHeight / 2);

    imageViewerContent.scrollLeft = newScrollLeft;
    imageViewerContent.scrollTop = newScrollTop;
  });

  fab?.addEventListener('click', () => openModal('Novo', 'Ação rápida do botão flutuante!'));

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      navDrawer.classList.remove('open');
      navDrawer.setAttribute('aria-hidden', 'true');
      const overlay = document.getElementById('drawerOverlay');
      if (overlay) overlay.remove();
      navDrawer.style.zIndex = '';
      closeImageViewer();
      closeModal();
    }
  });

  // Toast feedback
  function showToast(msg) {
    let toast = document.getElementById('toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'toast';
      toast.style.position = 'fixed';
      toast.style.bottom = '70px';
      toast.style.left = '50%';
      toast.style.transform = 'translateX(-50%)';
      toast.style.background = 'rgba(30,30,30,0.95)';
      toast.style.color = '#fff';
      toast.style.padding = '12px 22px';
      toast.style.borderRadius = '14px';
      toast.style.fontSize = '15px';
      toast.style.zIndex = 200;
      toast.style.opacity = 0;
      toast.style.transition = 'opacity .3s';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = 1;
    setTimeout(() => {
      toast.style.opacity = 0;
    }, 1800);
  }

  // Navegação dos botões principais da bottom-nav
  navItems.forEach(btn => {
    btn.addEventListener('click', () => {
      // Ativa visualmente o botão
      navItems.forEach(n => n.classList.remove('active'));
      btn.classList.add('active');
      showToast(`Você selecionou: ${btn.textContent}`);

      // Troca o conteúdo do main conforme o botão
      if (!main) return;
      const text = btn.textContent.trim();

      if (text === 'Início') {
        renderInicio(main);
      } else if (text === 'Buscar') {
        main.innerHTML = `
          <section class="hero">
            <h1 class="hero-title">Buscar</h1>
            <p class="hero-sub">Digite um local para saber mais:</p>
            <input type="text" class="search-input" placeholder="Qual local você procura?" style="width:100%;padding:12px;border-radius:8px;border:none;margin-top:12px;font-size:16px;">
          </section>
        `;
      } else if (text === 'Alertas') {
        main.innerHTML = `
          <section class="hero">
            <h1 class="hero-title">Alertas</h1>
            <p class="hero-sub">Você não possui novos alertas.</p>
          </section>
        `;
      } else if (text === 'Perfil') {
        main.innerHTML = `
          <section class="hero">
            <h1 class="hero-title">Perfil</h1>
            <p class="hero-sub">Gerencie suas informações e configurações.</p>
            <button class="btn" style="margin-top:18px;" data-action="open" data-title="Perfil" data-content="Aqui você pode editar seu perfil.">Editar Perfil</button>
          </section>
        `;
      }
    });
  });
});