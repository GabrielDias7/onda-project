document.addEventListener('DOMContentLoaded', () => {
  const btnMenu = document.getElementById('btnMenu');
  const navDrawer = document.getElementById('navDrawer');
  const btnTheme = document.getElementById('btnTheme');
  const modal = document.getElementById('modal');
  const modalClose = document.getElementById('modalClose');
  const fab = document.getElementById('fab');

  // Drawer toggle
  btnMenu.addEventListener('click', () => {
    const open = navDrawer.classList.toggle('open');
    navDrawer.setAttribute('aria-hidden', String(!open));
  });

  // Theme toggle
  const rootEl = document.body;
  btnTheme.addEventListener('click', ()=>{
    rootEl.classList.toggle('theme-dark');
    rootEl.classList.toggle('theme-light');
  });

  // Modal open/close
  document.addEventListener('click', (e)=>{
    const btn = e.target.closest('[data-action]');
    if(!btn) return;
    if(btn.dataset.action === 'open'){
      modal.setAttribute('aria-hidden','false');
    }
    if(btn.dataset.action === 'share'){
      navigator.share?.({title:document.title,text:'Compartilhe este projeto',url:location.href});
    }
  });

  modalClose.addEventListener('click', ()=>{
    modal.setAttribute('aria-hidden','true');
  });

  fab.addEventListener('click', ()=>{
    modal.setAttribute('aria-hidden','false');
  });

  // Bottom nav active state
  document.querySelectorAll('.bottom-nav .nav-item').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.bottom-nav .nav-item').forEach(n=>n.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Escape key closes
  document.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){
      navDrawer.classList.remove('open');
      navDrawer.setAttribute('aria-hidden','true');
      modal.setAttribute('aria-hidden','true');
    }
  });
});